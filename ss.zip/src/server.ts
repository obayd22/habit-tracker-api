import express from 'express';
import authRoutes from './routes/authRoutes.ts';
import habitRoutes from './routes/habitRoutes.ts'; 
import userRoutes from './routes/userRoutes.ts'; 
import cors from 'cors';
import morgan from 'morgan';
import helmet from 'helmet';
import { isTest } from '../env.ts'; 

const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended: true}));
app.use(morgan('dev', {
    skip: () => isTest(),
}));

app.get('/health', (req, res) => {
    res.send('<button>click</button>').status(200);
})

app.use('/api/auth', authRoutes)
app.use('/api/users', userRoutes)
app.use('/api/habit', habitRoutes)

export {app};

export default app;